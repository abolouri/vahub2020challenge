<head>
    <script
        src="https://code.jquery.com/jquery-3.5.1.min.js"
        integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
</head>

<body>
<button id="dbreset">Reset Data</button>

<button id="dbinsert">/tasks/ Insert Dummy Task (POST)</button>
<button id="dbput"> /tasks/ Insert Dummy Task (PUT)</button>
<button id="dbxhrput">/tasks/ Insert Dummy Task (Eva's XHR Put Test)</button>

<br><br><br>
<button id="dbtaskdel">/task/{id}  Insert + Delete Dummy Task (DELETE)</button>
<button id="dbtaskupdate">/task/{id}  Update Dummy Task (PATCH)</button>
<p id="serverreply"></p>
<!-- <button id="dbreset">Reset Data</button> -->



<script>
    const inputTask = document.createElement('input');
    inputTask.setAttribute("type", "text");
    inputTask.setAttribute("placeholder", "task name");

    const buttonAddTask = document.createElement('button');
    buttonAddTask.setAttribute('class', 'addButton');
    buttonAddTask.setAttribute('onClick', 'addTask();');

        function addTask() {
            var newTask = document.querySelector("input");
            var taskTitle = newTask.value;
            var saveTask = new XMLHttpRequest();
            saveTask.open('POST', 'https://va2020concept.cf/api/v1/tasks', true);
            saveTask.setRequestHeader("Content-Type", "application/json");
            var data = JSON.stringify({"title": taskTitle});
            saveTask.send(data);  }
</script>

<script>
    function getRandomWord(){

        randomarray = ["Alpha","Bravo","Charlie","Delta","Echo","Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Square","Rectangle","LoremIpsum","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        randomText = randomarray[Math.floor(Math.random() * randomarray.length)];
        return randomText;
    }
    $(document).ready(function(){
        $("#dbinsert").click(function(){
            sendDummyPOSTData();
        });
        $("#dbput").click(function(){
            sendDummyPUTData();
        });
        $("#dbxhrput").click(function(){
            sendDummyXHRData();
        });
        $("#dbtaskdel").click(function(){
            delDummyTaskData();
        });
        $("#dbtaskupdate").click(function(){
            updateDummyTaskData();
        });
    });

    function sendDummyPOSTData() {
        $.ajax({
            url: '/api/v1/tasks',
            type: 'POST',
            contentType: 'application/json',
            data: {
                title:getRandomWord(),
                description:getRandomWord()+getRandomWord()+getRandomWord(),
                start_time: Math.floor(Date.now() / 1000),
                expected_end: Math.floor(Date.now() / 1000)+(60*60), // 1 hour task
                time_logged: 300, // 5 minutes logged
                base_billing_rate: 0, // zero pennies per hour
                overtime_billing_rate : 0, // zero pennies per hour
                current_status : 0, // Not started

            },
            dataType: 'json',
        }).done(function( data ) {
            $( "#cardtarget" ).text( JSON.stringify (data) );
        });
        console.log("json posted!");
    };
    function sendDummyPUTData() {
        $.ajax({
            url: '/api/v1/tasks',
            type: 'PUT',
            contentType: 'application/json',
            data: {
                title:getRandomWord(),
                description:getRandomWord()+getRandomWord()+getRandomWord(),
                start_time: Math.floor(Date.now() / 1000),
                expected_end: Math.floor(Date.now() / 1000)+(60*60), // 1 hour task
                time_logged: 300, // 5 minutes logged
                base_billing_rate: 0, // zero pennies per hour
                overtime_billing_rate : 0, // zero pennies per hour
                current_status : 0, // Not started

            },
            dataType: 'json',
        }).done(function( data ) {
            $( "#serverreply" ).text( JSON.stringify (data) );
        });
        console.log("json posted!");
    };
    function sendDummyXHRData() {
            var newTask = 'test';
            var taskTitle = newTask.value;
            var saveTask = new XMLHttpRequest();
            saveTask.open('POST', 'https://va2020concept.cf/api/v1/tasks', true);
            saveTask.setRequestHeader("Content-Type", "application/json");
            var data = JSON.stringify({"title": taskTitle});
            saveTask.send(data);
    }
    function delDummyTaskData() {
        $.ajax({ //post something, get the task ID, then delete it
            url: '/api/v1/tasks',
            type: 'POST',
            contentType: 'application/json',
            data: {
                title:getRandomWord(),
                description:getRandomWord()+getRandomWord()+getRandomWord(),
                start_time: Math.floor(Date.now() / 1000),
                expected_end: Math.floor(Date.now() / 1000)+(60*60), // 1 hour task
                time_logged: 300, // 5 minutes logged
                base_billing_rate: 0, // zero pennies per hour
                overtime_billing_rate : 0, // zero pennies per hour
                current_status : 0, // Not started

            },
            dataType: 'json',
        }).done(function( data ) {
            $( "#serverreply" ).text( JSON.stringify (data.taskid) );
            $.ajax({ //post something, get the task ID, then delete it
                url: '/api/v1/task/'+data.taskid,
                type: 'DELETE',
                contentType: 'application/json',
                data: {
                },
                dataType: 'json',
            }).done(function( data ) {
                $( "#serverreply" ).append( JSON.stringify (data) );
            })
        });
        console.log("json posted!");

    }



    function updateDummyTaskData() {
        $.ajax({ //post something, get the task ID, then delete it
            url: '/api/v1/tasks',
            type: 'POST',
            contentType: 'application/json',
            data: {
                title:getRandomWord(),
                description:getRandomWord()+getRandomWord()+getRandomWord(),
                start_time: Math.floor(Date.now() / 1000),
                expected_end: Math.floor(Date.now() / 1000)+(60*60), // 1 hour task
                time_logged: 300, // 5 minutes logged
                base_billing_rate: 0, // zero pennies per hour
                overtime_billing_rate : 0, // zero pennies per hour
                current_status : 0, // Not started

            },
            dataType: 'json',
        }).done(function( data ) {
            $( "#serverreply" ).text( JSON.stringify (data.taskid) );
            $.ajax({ //post something, get the task ID, then delete it
                url: '/api/v1/task/'+data.taskid,
                type: 'PATCH',
                contentType: 'application/json',
                data: {
                    title:'UPDATETEST'+getRandomWord(),
                    description:'UPDATETEST'+getRandomWord()+getRandomWord()+getRandomWord(),
                    start_time: Math.floor(Date.now() / 1000),
                    expected_end: Math.floor(Date.now() / 1000)+(60*60), // 1 hour task
                    time_logged: 600, // 5 minutes logged
                    base_billing_rate: 1000, // zero pennies per hour
                    overtime_billing_rate : 0, // zero pennies per hour
                    current_status : 1, // Not started

                },
                dataType: 'json',
            }).done(function( data ) {
                $( "#serverreply" ).append( JSON.stringify (data) );
            })
        });
        console.log("json posted!");

    }



</script>
</body>
