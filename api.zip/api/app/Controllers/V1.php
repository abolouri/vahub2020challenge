<?php namespace App\Controllers;

class V1 extends BaseController
{
    private function sendJSONHeader(){
        header('Access-Control-Allow-Origin: *');
        header('Content-Type: application/json');
    }
    private function sendJSONError($errormessage="An Unknown Error Occurred"){
        $error_response = array();
        $error_response['code'] = 400;
        $error_response['message'] = $errormessage;
        print(json_encode($error_response));
        exit();
    }
    public function index()
    {
        echo 'test';
       // return view('welcome_message');
    }
    public function datatest()
    {
        return view('api_test');
    }
    public function task($taskid=0){ // get or update data about an individual task

        //TODO: If time permits, add an authentication / multiuser system
        $userid = 1;

        $taskmodel = new \App\Models\Task;
        $listoftasks = $taskmodel->get_tasks_for_user($userid);


        //print($this->task->get_tasks_for_user());
        $this->sendJSONHeader();
        if ($taskid==0){
            $this->sendJSONError('Please specify a task ID');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'GET') { //get item from database
            $taskdata = $taskmodel->get_specific_task_for_user($userid,$taskid);
            if ($taskdata === null){
                $this->sendJSONError('Task ID Does not exist');
            } else {
                print($taskdata);
            }

        }elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') { //put more logged time into a task


            parse_str(file_get_contents("php://input"),$post_vars);
            if (!isset($post_vars['time_logged'])){
                $this->sendJSONError("Please include a title in your form submission");
            } else{
                $newtime = $post_vars['time_logged'];
            }
            $taskdata = $taskmodel->add_time_to_task($userid,$taskid,$newtime);

            if ($taskdata === null){
                $this->sendJSONError('Task ID Does not exist');
            } else {
                print($taskdata);
            }
        }elseif ($_SERVER['REQUEST_METHOD'] === 'PATCH') { //update task in database
            //TODO: do something
            parse_str(file_get_contents("php://input"),$post_vars);
            if (!isset($post_vars['title'])){
                $this->sendJSONError("Please include a title in your form submission");
            } else{
                $title = $post_vars['title'];
            }
            if (!isset($post_vars['description'])){
                $description = '';
            } else {
                $description = $post_vars['description'];
            }
            if(!isset($post_vars['start_time'])){
                $this->sendJSONError('Please enter the task start time');
                //TODO: add a validation error once the appropriate field is included on the client-side
                $start_time = time();
            } else {
                $start_time = $post_vars['start_time'];
            }
            if(!isset($post_vars['expected_end'])){
                $this->sendJSONError('Please enter the estimated end time');
                //TODO: add a validation error once the appropriate field is included on the client-side
                $expected_end = time()+3600;
            } else {
                $expected_end = $post_vars['expected_end'];
            }
            if(!isset($post_vars['time_logged'])){
                $time_logged = 0;
            } else {
                $time_logged = $post_vars['time_logged'];
            }
            if(!isset($post_vars['is_billable'])){
                $is_billable = 0;
            } else {
                $is_billable = $post_vars['is_billable'];
            }
            if(!isset($post_vars['base_billing_rate'])){
                $base_billing_rate = 0;
            } else {
                $base_billing_rate = $post_vars['base_billing_rate'];
            }
            if(!isset($post_vars['overtime_billing_rate'])){
                $overtime_billing_rate = 0;
            } else {
                $overtime_billing_rate = $post_vars['overtime_billing_rate'];
            }
            if(!isset($post_vars['current_status'])){
                $current_status = 0;
            } else {
                $current_status = $post_vars['current_status'];
            }

            $responsedata = $taskmodel->update_specific_task_for_user($userid,$taskid,$title,$description,$start_time,$expected_end,$time_logged,$is_billable,$base_billing_rate,$overtime_billing_rate,$current_status);

            if ($responsedata === null){
                $this->sendJSONError('Task ID Does not exist');
            } else {
                exit($responsedata);
                //exit(json_encode($response));


            }
        }elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') { //delete task in database
            //print('The DELETE task on the database will go here '.$taskid);
            $taskdata = $taskmodel->delete_specific_task_for_user($userid,$taskid);
            if ($taskdata === null){
                $this->sendJSONError('Task ID Does not exist');
            } else {
                print($taskdata);
            }

        }else { //request unknown
            $this->sendJSONError('Invalid Request Method');
        }

    }
    public function tasks($auxiliarypath='')
    {
        $this->sendJSONHeader();

        //TODO: If time permits, add an authentication / multiuser system
        $userid = 1;
        $taskmodel = new \App\Models\Task;

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {//get item from database
            $listoftasks = $taskmodel->get_tasks_for_user($userid);
            print($listoftasks);

            exit();

        }elseif ($_SERVER['REQUEST_METHOD'] === 'POST') { //insert task in database
            //TODO: do something
            parse_str(file_get_contents("php://input"),$post_vars);
            if (!isset($post_vars['title'])){
                $this->sendJSONError("Please include a title in your form submission");
            } else{
                $title = $post_vars['title'];
            }
            if (!isset($post_vars['description'])){
                $description = '';
            } else {
                $description = $post_vars['description'];
            }
            if(!isset($post_vars['start_time'])){
                $this->sendJSONError('Please enter the task start time');
                //TODO: add a validation error once the appropriate field is included on the client-side
                $start_time = time();
            } else {
                $start_time = $post_vars['start_time'];
            }
            if(!isset($post_vars['expected_end'])){
                $this->sendJSONError('Please enter the estimated end time');
                //TODO: add a validation error once the appropriate field is included on the client-side
                $expected_end = time()+3600;
            } else {
                $expected_end = $post_vars['expected_end'];
            }
            if(!isset($post_vars['time_logged'])){
                $time_logged = 0;
            } else {
                $time_logged = $post_vars['time_logged'];
            }
            if(!isset($post_vars['is_billable'])){
                $is_billable = 0;
            } else {
                $is_billable = $post_vars['is_billable'];
            }
            if(!isset($post_vars['base_billing_rate'])){
                $base_billing_rate = 0;
            } else {
                $base_billing_rate = $post_vars['base_billing_rate'];
            }
            if(!isset($post_vars['overtime_billing_rate'])){
                $overtime_billing_rate = 0;
            } else {
                $overtime_billing_rate = $post_vars['overtime_billing_rate'];
            }
            if(!isset($post_vars['current_status'])){
                $current_status = 0;
            } else {
                $current_status = $post_vars['current_status'];
            }
            $responsedata = $taskmodel->insert_new_task($userid,$title,$description,$start_time,$expected_end,$time_logged,$is_billable,$base_billing_rate,$overtime_billing_rate,$current_status);

            exit(json_encode($responsedata));

        }elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') { //insert task in database
            $this->sendJSONError('PUT endpoint has been replaced with POST');
        }elseif ($_SERVER['REQUEST_METHOD'] === 'DELETEALL') { //update task in database
            //Dangerous function for dev testing only - clear all data from db
            print('The DELETE task to flush the entire development database will go here ');
        }else { //request unknown
            $this->sendJSONError('Invalid Request Method');
        }
    }


    //--------------------------------------------------------------------

}
