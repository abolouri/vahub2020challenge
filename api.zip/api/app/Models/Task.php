<?php
namespace App\Models;

use CodeIgniter\Model;

class Task extends Model
{


    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

    public function get_tasks_for_user($userid=0)
    {
        //return all tasks for user in json format
        $db = db_connect();

        $sql = "SELECT * FROM tasks WHERE userid = ? ";
        $query = $db->query($sql, [$userid]);


        //$sql = "SELECT * FROM ".$this->table." WHERE userid = ".intval($userid);
        //$query = $db->query($sql,array($userid));
        // Return JSON Array formatted for front-end use as per Eva's requirements.


        // iterate over row, add it to an internal array which we'll then convert into a json array.
        $responsearray = array();

        foreach ($query->getResult() as $row)
        {
            $taskrow = array(
                'id' => intval($row->id),
                'title' => $row->title,
                'description' => $row->description,
                'start_time'=>intval($row->start_time),
                'expected_end'=>intval($row->expected_end),
                'time_logged'=>intval($row->time_logged),
                'is_billable'=>intval($row->is_billable),
                'base_billing_rate'=>intval($row->base_billing_rate),
                'overtime_billing_rate'=>intval($row->overtime_billing_rate),
                'current_status'=>intval($row->current_status),
                );
            $responsearray[] =$taskrow;
        }

        return json_encode($responsearray);
    }
    public function insert_new_task($userid,$title,$description,$start_time,$expected_end,$time_logged,$is_billable,$base_billing_rate,$overtime_billing_rate,$current_status )
    {
        $db = db_connect();
        // Prepare a safe query
        $pQuery = $db->prepare(function($db)
        {
            return $db->table('tasks')
                ->insert([
                    'userid' => 'x',
                    'title'    => 'x',
                    'description'    => 'x',
                    'start_time'   => 'x',
                    'expected_end' => 'x',
                    'time_logged' => 'x',
                    'is_billable' => 'x',
                    'base_billing_rate' => 'x',
                    'overtime_billing_rate' => 'x',
                    'current_status' => 'x',
                ]);
        });

        // Run the Query
        $results = $pQuery->execute($userid,$title,$description,$start_time,$expected_end,$time_logged,$is_billable,$base_billing_rate,$overtime_billing_rate,$current_status);

        $response = array('code' => 200,'message'=>'Received data','taskid'=>$results->connID->insert_id,'debugresp1'=> $title);
        return $response;
    }
    public function get_specific_task_for_user($userid=0,$taskid=0)
    {
        $db = db_connect();

        $sql = "SELECT * FROM tasks WHERE userid = ? AND id = ? LIMIT 1";
        $query = $db->query($sql, [$userid, $taskid]);


        //$sql = "SELECT * FROM ".$this->table." WHERE userid = ".intval($userid);
        //$query = $db->query($sql,array($userid));
        // Return JSON Array formatted for front-end use as per Eva's requirements.


        // iterate over row, add it to an internal array which we'll then convert into a json array.
        $response = null;

        foreach ($query->getResult() as $row)
        {
            $response = array(
                'title' => $row->title,
                'description' => $row->description,
                'start_time'=>intval($row->start_time),
                'expected_end'=>intval($row->expected_end),
                'time_logged'=>intval($row->time_logged),
                'is_billable'=>intval($row->is_billable),
                'base_billing_rate'=>intval($row->base_billing_rate),
                'overtime_billing_rate'=>intval($row->overtime_billing_rate),
                'current_status'=>intval($row->current_status),
            );
        }
        return json_encode($response);
    }
    public function delete_specific_task_for_user($userid=0,$taskid=0)
    {
        $db = db_connect();

        $sql = "DELETE FROM tasks WHERE userid = ? AND id = ?";
        //$query = $db->delete(['userid'=>$userid, 'id'=>$taskid]);
        $query = $db->query($sql, [$userid, $taskid]);

        // Return JSON Array formatted for front-end use as per Eva's requirements.
        $delcount = $query->connID->affected_rows;
        if ($delcount >= 1){
            $response = array('code'=>200,'message'=>'Deleted Task');
        } else {
            $response = array('code'=>404,'message'=>'Invalid Task ID- Has the task already been deleted?');
        }

        return json_encode($response);
    }

    public function add_time_to_task($userid=0,$taskid=0,$time_logged=0)
    {
        $db = db_connect();
        // Prepare a safe query

        $sql = "UPDATE tasks SET time_logged=? WHERE userid = ? AND id = ?;";
        //$query = $db->delete(['userid'=>$userid, 'id'=>$taskid]);
        $results = $db->query($sql, [
            $time_logged,

            $userid, intval($taskid),
        ]);

        // Run the Query
        //$results = $pQuery->execute($title,$description,$start_time,$expected_end,$time_logged,$is_billable,$base_billing_rate,$overtime_billing_rate,$current_status,$userid,$taskid);
        //$results = $query->execute();
        $updatecount = $results->connID->affected_rows;
        if ($updatecount >= 1){
            $response = array('code'=>200,'message'=>'Added time to task');
        } else {
            $response = array('code'=>404,'message'=>'Invalid Task ID- Has the task been deleted?');
        }

        return json_encode($response);
    }

    public function update_specific_task_for_user($userid=0,$taskid=0,$title,$description,$start_time,$expected_end,$time_logged,$is_billable,$base_billing_rate,$overtime_billing_rate,$current_status)
    {
        $db = db_connect();
        // Prepare a safe query

        $sql = "UPDATE tasks SET title=?,description=?,start_time=?,expected_end=?,time_logged=?,is_billable=?,base_billing_rate=?,overtime_billing_rate=?,current_status=? WHERE userid = ? AND id = ?;";
        //$query = $db->delete(['userid'=>$userid, 'id'=>$taskid]);
        $results = $db->query($sql, [$title,
            $description,
            $start_time,
            $expected_end,
            $time_logged,
            $is_billable,
            $base_billing_rate,
            $overtime_billing_rate,
            $current_status,

            $userid, intval($taskid),
        ]);

        // Run the Query
        //$results = $pQuery->execute($title,$description,$start_time,$expected_end,$time_logged,$is_billable,$base_billing_rate,$overtime_billing_rate,$current_status,$userid,$taskid);
        //$results = $query->execute();
        $updatecount = $results->connID->affected_rows;
        if ($updatecount >= 1){
            $response = array('code'=>200,'message'=>'Updated Task');
        } else {
            $response = array('code'=>404,'message'=>'Invalid Task ID- Has the task already been deleted?');
        }

        return json_encode($response);
    }

}
